#!/usr/bin/env python3

from setuptools import setup, find_packages

setup(
    name='pyfreebody',
    version='0.1.0',
    packages=find_packages(include=['pyfreebody']),
        install_requires=[
            "Pillow"
        ]

)
