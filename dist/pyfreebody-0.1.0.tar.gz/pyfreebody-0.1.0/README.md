# pyFreeBody
A free-body diagram generator for Python 🔲

# Usage
The following system setup produces [this output](./examples/simple.out.png)
![simple demo](./examples/simple.png)

